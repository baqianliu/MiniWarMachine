---
name: Security report
about: Report a security issue or vunerability in MicroPython
title: ''
labels: security
assignees: ''

---

* Remove all placeholder text before submitting the new issue.

* If you need to raise this issue privately with the MicroPython team, please email contact@micropython.org instead.

* Include a clear and concise description of what the security issue is.

* What does this issue allow an attacker to do?
